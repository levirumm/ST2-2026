import timeit
import random


def linear_search(array, target):
    for i in range(len(array)):
        if array[i] == target:
            return i 
    return -1


def binary_search(array, target):
    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1


def test_linear_search():
    # Testing linear search for different data sizes
    range_1 = range(10000)
    range_2 = range(1000000)
    target_1 = random.randint(0, 10000) # Random target value in range 1 range
    target_2 = random.randint(0, 1000000) # Random target value in range 2 range
    range_1_time = timeit.timeit(lambda: linear_search(range_1, target_1), number=100)
    range_2_time = timeit.timeit(lambda: linear_search(range_2, target_2), number=100)
    print(f"Linear search time for 10,000 elements: {range_1_time:.6f} seconds")
    print(f"Linear search time for 1,000,000 elements: {range_2_time:.6f} seconds")


def test_binary_search():
    # Testing binary search for different data sizes
    range_1 = range(10000)
    range_2 = range(1000000)
    target_1 = random.randint(0, 10000) # Random target value in range 1 range
    target_2 = random.randint(0, 1000000) # Random target value in range 2 range
    range_1_time = timeit.timeit(lambda: binary_search(range_1, target_1), number=100)
    range_2_time = timeit.timeit(lambda: binary_search(range_2, target_2), number=100)
    print(f"Binary search time for 10,000 elements: {range_1_time:.6f} seconds")
    print(f"Binary search time for 1,000,000 elements: {range_2_time:.6f} seconds")


def compare_linear_and_binary_search():
    # Comparing linear and binary search efficiency
    sorted_list = list(range(1000000))

    # Test cases
    target = random.randint(0, 999999)  # Random target value
    linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
    binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

    print(f"Linear search execution time: {linear_time:.6f} seconds")
    print(f"Binary search execution time: {binary_time:.6f} seconds")


test_linear_search()

test_binary_search()

compare_linear_and_binary_search()