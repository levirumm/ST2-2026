import random
import timeit


def linear_search(array, target):
    for i in range(len(array)):
        if array[i] == target:
            return i 
    return -1


def binary_search(array, target):
    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1


def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """
    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):
        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):
            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break
    return arr


def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """
    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element
    return arr


def insertion_sort_and_linear_search(array, target):
    sorted = insertion_sort(array)
    return linear_search(sorted, target)
    

def bubble_sort_and_linear_search(array, target):
    sorted = bubble_sort(array)
    return linear_search(sorted, target)


def insertion_sort_and_binary_search(array, target):
    sorted = insertion_sort(array)
    return binary_search(sorted, target)


def bubble_sort_and_binary_search(array, target):
    sorted = bubble_sort(array)
    return binary_search(sorted, target)


def time_sort_and_search(sort_and_search_function, sort_str, search_str):   
    # Measure time for both lists
    time_1 = timeit.timeit(
        lambda: sort_and_search_function(list_1, target_1), number=100
    )
    time_2 = timeit.timeit(
        lambda: sort_and_search_function(list_2, target_2), number=100
    )
    print(
        f"{sort_str.title()} sort and {search_str} search time "
        f"for 1000 elements: {time_1}"
    )
    print(
        f"{sort_str.title()} sort and {search_str} search time "
        f"for 10000 elements: {time_2}\n"
    )


# Initialise lists of different length and targets from lists
list_1 = [random.randint(1, 1000) for _ in range(1000)]
list_2 = [random.randint(1, 10000) for _ in range(10000)]
target_1 = random.choice(list_1)
target_2 = random.choice(list_2)


time_sort_and_search(
    insertion_sort_and_linear_search, "insertion", "linear"
)

time_sort_and_search(
    bubble_sort_and_linear_search, "bubble", "linear"
)

time_sort_and_search(
    insertion_sort_and_binary_search, "insertion", "binary"
)

time_sort_and_search(
    bubble_sort_and_binary_search, "bubble", "binary"
)