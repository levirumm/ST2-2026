import random
import timeit

def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps 
    through the list, compares adjacent elements, and swaps them 
    if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """
    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):
        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the 
        # list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't 
        # need to compare them again
        for j in range(0, n - i - 1):
            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than
                # the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate 
                # that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, 
        # the list is sorted, and we can exit early
        if not swapped:
            break
    return arr


def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """
    # Traverse through all elements in the list, starting from 
    # the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted
        #  into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are 
        # greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct 
        # position in the sorted part of the list
        arr[j + 1] = current_element
    return arr


def insertion_list_sort():
    unsorted_list_1 = [64, 1, 12, 22, 11]
    unsorted_list_2 = [64, 1, 12, 22, 11, 8, 9, 77, 7, 3, 2]
    sorted_list_1 = insertion_sort(unsorted_list_1)
    sorted_list_2 = insertion_sort(unsorted_list_2)
    print("Sorted array 1:", sorted_list_1)
    print("Sorted array 2:", sorted_list_2)


def bubble_list_sort():
    unsorted_list_1 = [3, 1, 6, 5, 0]
    unsorted_list_2 = [8, 8, 5, 3, 11, 8, 9, 102, 7, 6, 9]
    sorted_list_1 = bubble_sort(unsorted_list_1)
    sorted_list_2 = bubble_sort(unsorted_list_2)
    print("Sorted array 1:", sorted_list_1)
    print("Sorted array 2:", sorted_list_2)


def compare_insertion_and_bubble_sort():
    # Generate random unsorted list
    unsorted_list = [random.randint(1, 1000) for _ in range(10000)]

    # Measure and compare the runtimes of Bubble Sort and Insertion Sort
    bubble_sort_time = timeit.timeit(
        lambda: bubble_sort(unsorted_list.copy()), number=1
    )
    insertion_sort_time = timeit.timeit(
        lambda: insertion_sort(unsorted_list.copy()), number=1
    )
    print(f"Bubble Sort Execution Time: {bubble_sort_time:.6f} seconds")
    print(f"Insertion Sort Execution Time: {insertion_sort_time:.6f} seconds")

insertion_list_sort()
bubble_list_sort()
compare_insertion_and_bubble_sort()