import tkinter as tk
from tkinter import messagebox


class RBNode:
    def __init__(self, name, phone, color="red"):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RBTree:
    def __init__(self):
        self.NIL = RBNode(None, None, color="black")
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x

        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y

        y.right = x
        x.parent = y

    def insert(self, name, phone):
        new_node = RBNode(name, phone)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.name < current.name:
                current = current.left
            elif new_node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return

        new_node.parent = parent

        if parent is None:
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "red"
        self.fix_insert(new_node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == "red":
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left
                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.left_rotate(k.parent.parent)

        self.root.color = "black"

    def transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z == self.NIL:
            return

        if z.left == self.NIL:
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            if y.parent != z:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

    def search(self, node, name):
        if node == self.NIL or name == node.name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, node, res=None):
        if res is None:
            res = []
        if node != self.NIL:
            self.inorder(node.left, res)
            res.append((node.name, node.phone))
            self.inorder(node.right, res)
        return res


class RBApp:
    def __init__(self, master):
        self.tree = RBTree()
        self.master = master
        master.title("Red-Black Tree Contact Directory")

        self.frame = tk.Frame(master)
        self.frame.pack(pady=10)

        tk.Label(self.frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(self.frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(self.frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(self.frame)
        self.phone_entry.grid(row=1, column=1)

        self.btn_frame = tk.Frame(master)
        self.btn_frame.pack(pady=5)

        tk.Button(self.btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(self.btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(self.btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(self.btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)

        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=800, height=400, bg="white")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()
        if not name or not phone:
            messagebox.showwarning("Input Error", "Enter both Name and Phone.")
            return
        self.tree.insert(name, phone)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)
        if node != self.tree.NIL:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\n")
        else:
            self.output_text.insert(tk.END, "Not found")

    def delete_contact(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showwarning("Input Error", "Enter Name to delete.")
            return
        self.tree.delete(name)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        for n, p in self.tree.inorder(self.tree.root):
            self.output_text.insert(tk.END, f"{n}: {p}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return
        width = self.canvas.winfo_width()
        self._draw_node(self.tree.root, width // 2, 20, width // 4)

    def _draw_node(self, node, x, y, offset):
        if node == self.tree.NIL:
            return

        radius = 20
        color = "red" if node.color == "red" else "black"
        text_color = "white" if node.color == "black" else "black"

        if node.left != self.tree.NIL:
            self.canvas.create_line(x, y+radius, x-offset, y+70-radius)
            self._draw_node(node.left, x-offset, y+70, offset//2)

        if node.right != self.tree.NIL:
            self.canvas.create_line(x, y+radius, x+offset, y+70-radius)
            self._draw_node(node.right, x+offset, y+70, offset//2)

        self.canvas.create_oval(x-radius, y-radius, x+radius, y+radius, fill=color)
        self.canvas.create_text(x, y, text=node.name[:10], fill=text_color, font=("Arial", 10, "bold"))


if __name__ == "__main__":
    root = tk.Tk()
    app = RBApp(root)
    root.mainloop()