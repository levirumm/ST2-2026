from collections import deque


class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

    def preorder(self, root):
        if root:
            print(root.value, end=" ")
            self.preorder(root.left)
            self.preorder(root.right)
    
    def inorder(self, root):
        if root:
            self.inorder(root.left)
            print(root.value, end=" ")
            self.inorder(root.right)
    
    def postorder(self, root):
        if root:
            self.postorder(root.left)
            self.postorder(root.right)
            print(root.value, end=" ")
    
    def count_nodes(self, root):
        if root is None:
            return 0
        return 1 + self.count_nodes(root.left) + self.count_nodes(root.right)
    
    def height(self, root):
        if root is None:
            return 0
        return 1 + max(self.height(root.left), self.height(root.right))
    
    def search_bst(self, root, val):
        if root is None or root.value == val:
            return root
        if val < root.value:
            return self.search_bst(root.left, val)
        else:
            return self.search_bst(root.right, val)
    
    def insert_bst(self, root, val):
        if root is None:
            return Node(val)
        if val < root.value:
            root.left = self.insert_bst(root.left, val)
        else:
            root.right = self.insert_bst(root.right, val)
        return root
    
    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current
    
    def delete_node(self, root, val):
        if root is None:
            return root
        if val < root.value:
            root.left = self.delete_node(root.left, val)
        elif val > root.value:
            root.right = self.delete_node(root.right, val)
        else:
        # Node with 1 or no child
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            # Node with two children
            temp = self.find_min(root.right)
            root.value = temp.value
            root.right = self.delete_node(root.right, temp.value)
        return root
    
    def level_order(self, root):
        if not root:
            return
        queue = deque([root])
        while queue:
            node = queue.popleft()
            print(node.value, end=' ')
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)


class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
    
    
class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            # Update phone if contact already exists
            root.phone = phone
        return root
    
    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root

    def inorder(self, root):
        if root:
            self.inorder(root.left)
            print(f"Name: {root.name}, Phone: {root.phone}")
            self.inorder(root.right)


# Testing the binary search tree
directory = ContactDirectory()
directory.root = directory.insert(directory.root, 'Alice', '123-456-7890')
directory.root = directory.insert(directory.root, 'Bob', '234-567-8901')
directory.root = directory.insert(directory.root, 'Eve', '345-678-9012')

print("All contacts:")
directory.inorder(directory.root)

print("\nSearching for Bob:")
contact = directory.search(directory.root, 'Bob')
if contact:
    print(f"Found contact: {contact.name} - {contact.phone}")
else:
    print("Contact not found")

print("\nDeleting Alice:")
directory.root = directory.delete(directory.root, 'Alice')
directory.inorder(directory.root)