import time
import random
import string
import tkinter as tk
from tkinter import ttk


ELEMENTS = 100000



class RBNode:
    def __init__(self, name, phone, color="red"):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RBTree:
    def __init__(self):
        self.NIL = RBNode(None, None, color="black")
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x

        y.parent = x.parent
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y

        y.right = x
        x.parent = y

    def insert(self, name, phone):
        new_node = RBNode(name, phone)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.name < current.name:
                current = current.left
            elif new_node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return

        new_node.parent = parent

        if parent is None:
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "red"
        self.fix_insert(new_node)

    def fix_insert(self, k):
        while k.parent and k.parent.color == "red":
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left
                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.left_rotate(k.parent.parent)

        self.root.color = "black"

    def transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z == self.NIL:
            return

        if z.left == self.NIL:
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            if y.parent != z:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

    def search(self, node, name):
        if node == self.NIL or name == node.name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, node, res=None):
        if res is None:
            res = []
        if node != self.NIL:
            self.inorder(node.left, res)
            res.append((node.name, node.phone))
            self.inorder(node.right, res)
        return res


def benchmark(n=ELEMENTS, search_fraction=0.5, delete_count=100):
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    rb = RBTree()

    start = time.time()
    for i in range(n):
        rb.insert(names[i], phones[i])
    insert_time = time.time() - start

    search_names = random.sample(names, int(n * search_fraction))

    start = time.time()
    for name in search_names:
        rb.search(rb.root, name)
    search_time = time.time() - start

    delete_names = random.sample(names, delete_count)

    start = time.time()
    for name in delete_names:
        rb.delete(name)
    delete_time = time.time() - start

    return insert_time, search_time, delete_time


class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("Red-Black Tree Benchmark")

        self.label = tk.Label(master, text=f"Run benchmark with {ELEMENTS} entries?")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)

        self.result_text = tk.Text(master, height=10, width=50)
        self.result_text.pack(pady=10)

        self.tree = ttk.Treeview(master, columns=("Time",), show='headings')
        self.tree.heading("Time", text="Time (seconds)")
        self.tree.pack(pady=10)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)

        insert_time, search_time, delete_time = benchmark()

        summary = (
            f"Insertion Time: {insert_time:.6f}s\n"
            f"Search Time: {search_time:.6f}s\n"
            f"Deletion Time: {delete_time:.6f}s\n"
        )

        self.result_text.insert(tk.END, summary)

        for row in self.tree.get_children():
            self.tree.delete(row)

        self.tree.insert('', tk.END, values=(f"{insert_time:.6f}",))
        self.tree.insert('', tk.END, values=(f"{search_time:.6f}",))
        self.tree.insert('', tk.END, values=(f"{delete_time:.6f}",))


if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()