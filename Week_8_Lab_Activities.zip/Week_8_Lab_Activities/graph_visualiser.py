# graph_visualiser.py
from graph import Graph
import tkinter as tk
from tkinter import simpledialog
import math

class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph

        # Canvas
        self.canvas = tk.Canvas(self, width=400, height=400, bg='white')
        self.canvas.pack()

        # Buttons frame
        button_frame = tk.Frame(self)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Add Vertex", command=self.add_vertex).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Add Edge", command=self.add_edge).pack(side=tk.LEFT, padx=5)

        self.vertex_positions = {}
        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        radius = 20
        spacing = 100

        n = len(self.graph.graph)
        angle_gap = 360 / n if n else 0
        center_x, center_y = 200, 200

        # Draw vertices
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)

            self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill='lightblue'
            )
            self.canvas.create_text(x, y, text=v)

        # Draw edges
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None
                )

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

    def add_vertex(self):
        name = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if name:
            self.graph.add_vertex(name)
            self.draw_graph()

    def add_edge(self):
        v1 = simpledialog.askstring("Add Edge", "From vertex:")
        v2 = simpledialog.askstring("Add Edge", "To vertex:")

        if not v1 or not v2:
            return

        if self.graph.weighted:
            weight = simpledialog.askinteger("Weight", "Enter weight:")
            if weight is None:
                return
            self.graph.add_edge(v1, v2, weight)
        else:
            self.graph.add_edge(v1, v2)

        self.draw_graph()


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()