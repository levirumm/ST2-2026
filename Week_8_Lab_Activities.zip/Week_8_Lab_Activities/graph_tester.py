from graph import Graph



# Basic undirected graph tests
print("Testing undirected graph")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
g.add_edge('D', 'A')
g.print_graph()
print()

print("Removing an edge")
g.remove_edge('A', 'B')
g.print_graph()
print()

print("Removing a vertex")
g.remove_vertex('D')
g.print_graph()
print()


# Directed graph tests
print("Testing directed graph")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
g.add_edge('D', 'A')
g.print_graph()
print()

print("Removing an edge")
g.remove_edge('A', 'B')
g.print_graph()
print()

print("Removing a vertex")
g.remove_vertex('D')
g.print_graph()
print()


# Weighted graph tests
print("Testing weighted graph")
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)

g.print_graph()


# BFS on the graph from Activity 1
print("Testing BFS\n")

g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('B', 'D')

g.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()


# DFS on the same graph
print("Testing DFS\n")

g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'E')
g.add_edge('C', 'D')

g.print_graph()
print()

print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()


print("Cycle Detection")
#cycle detection in undirected graphs
# Create graph with a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # Closing the cycle
cycle_graph.print_graph()
print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

# Create weighted directed graph
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()



