from tkinter import * 

# Trig values used in rotation matrix
COS_60 = 0.5
SIN_60 = -0.866 # Approximation
     
     
class KochSnowflake: 
    def __init__(self): 
        window = Tk()
        window.title("Kock Snowflake")
         
        self.width = 400 
        self.height = 400 
        self.canvas = Canvas(window,  
            width = self.width, height = self.height) 
        self.canvas.pack() 
         
        # Add a label, an entry, and a button to frame1 
        frame1 = Frame(window) # Create and add a frame to window 
        frame1.pack() 
         
        Label(frame1,  
            text = "Enter an order: ").pack(side = LEFT) 
        self.order = StringVar() 
        Entry(frame1, textvariable = self.order,  
                      justify = RIGHT).pack(side = LEFT) 
        Button(frame1, text = "Display Koch Snowflake",  
            command = self.display).pack(side = LEFT) 
         
        window.mainloop() # Create an event loop 
         
    def display(self): 
        """Displayes Koch snowflake of given order."""
        self.canvas.delete("line")
        padding = 80
        p1 = [padding, self.height - padding] 
        p2 = [self.width - padding, self.height - padding] 
        p3 = self.getApex(p1, p2)

        self.displaySnowflake(
            int(self.order.get()), p1, p2, p3
        ) 

    def displaySnowflake(self, order, p1, p2, p3):
        """Recursively draws each side of the triangle."""
        self.drawSide(order, p1, p2)
        self.drawSide(order, p2, p3)
        self.drawSide(order, p3, p1)
    
    def drawSide(self, order, p1, p2):
        """
        Draws line if order 0. Else, divides into thirds, 
        finds apex of outward triangle, and recursively draws 
        each new line segment.
        """
        if order == 0:
            self.drawLine(p1, p2)
        else:
            t1, t2 = self.divideIntoThirds(p1, p2)
            a = self.getApex(t2, t1)
            # Draw each of the 4 newly created sides
            self.drawSide(order-1, p1, t1)
            self.drawSide(order-1, t1, a)
            self.drawSide(order-1, a, t2)
            self.drawSide(order-1, t2, p2)
        
    def drawLine(self, p1, p2): 
        self.canvas.create_line( 
            p1[0], p1[1], p2[0], p2[1], tags="line"
        ) 
    
    def divideIntoThirds(self, p1, p2):
        """
        Returns two points that divide the line into thirds.
        """
        t1 = 2 * [0] 
        t2 = 2 * [0] 

        third_horizontal_distance = (p2[0] - p1[0]) / 3
        third_vertical_distance = (p2[1] - p1[1]) / 3

        t1[0] = p1[0] + third_horizontal_distance
        t1[1] = p1[1] + third_vertical_distance

        t2[0] = p2[0] - third_horizontal_distance
        t2[1] = p2[1] - third_vertical_distance
    
        return t1, t2
         
    def getApex(self, p1, p2):
        """
        Returns apex of tringle, found by rotating line 60 degrees
        counterclockwise with p1 fixed.
        """
        p = 2 * [0]
        p[0] = (p2[0]-p1[0])*COS_60 - (p2[1]-p1[1])*SIN_60 + p1[0]
        p[1] = (p2[0]-p1[0])*SIN_60 + (p2[1]-p1[1])*COS_60 + p1[1]
        
        return p
 
KochSnowflake()