import timeit
import random


def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2] # Integer division
        right_split = array[len(array)//2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)        

        return merge(left, right)

        
def merge(left, right):
    merged = []

    left_pointer = 0
    right_pointer = 0

    merging = True

    while merging:

        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element: # Equal items
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1

        if left_pointer >= len(left): # Reached end of left list
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right): # Reached end of right list
            merged.extend(left[left_pointer:])
            merging = False

    return merged


def insertion_sort(arr):
    # Traverse through all elements in the list, 
    # starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and 
        # inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list 
        # that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct 
        # position in the sorted part of the list
        arr[j + 1] = current_element

    return arr


def test_merge_sort():
    list_1 = [random.randint(1, 100) for _ in range(5)]
    list_2 = [random.randint(1, 100) for _ in range(15)]

    print(f"Unsorted: {list_1}")
    print(f"Sorted: {merge_sort(list_1)}\n")
    print(f"Sorted: {list_2}")
    print(f"Unsorted: {merge_sort(list_2)}")


def test_insertion_sort():
    list_1 = [random.randint(1, 100) for _ in range(5)]
    list_2 = [random.randint(1, 100) for _ in range(15)]

    print(f"Unsorted: {list_1}")
    print(f"Sorted: {insertion_sort(list_1)}\n")
    print(f"Sorted: {list_2}")
    print(f"Unsorted: {insertion_sort(list_2)}")


def compare_merge_and_insertion_sort():
    list_1 = [random.randint(1, 100) for _ in range(100)]
    list_2 = [random.randint(1, 10000) for _ in range(10000)]

    insertion_time_1 = timeit.timeit(lambda: insertion_sort(list_1), number=10)
    insertion_time_2 = timeit.timeit(lambda: insertion_sort(list_2), number=10)
    merge_time_1 = timeit.timeit(lambda: merge_sort(list_1), number=10)
    merge_time_2 = timeit.timeit(lambda: merge_sort(list_2), number=10)

    print(
        f"Insertion sort for 100 element list: {insertion_time_1:.6f}\n"
        f"Insertion sort for 10000 element list: {insertion_time_2:.6f}\n"
        f"Merge sort for 100 element list: {merge_time_1:.6f}\n"
        f"Merge sort for 10000 element list: {merge_time_2:.6f}"
    )
   

#test_merge_sort()
#test_insertion_sort()
compare_merge_and_insertion_sort()