import timeit


moves: int = 0


def moveDisks(n, fromTower, toTower, auxTower):
    global moves

    if n == 1: # Stopping condition  
        moves += 1
    else:  
        moveDisks(n - 1, fromTower, auxTower, toTower) 
        moves += 1 
        moveDisks(n - 1, auxTower, toTower, fromTower) 


def test_move_disks():
    size_1 = 10
    size_2 = 25

    time_1 = timeit.timeit(
        lambda: moveDisks(size_1, 'A', 'B', 'C'), number=10
    )
    time_2 = timeit.timeit(
        lambda: moveDisks(size_2, 'A', 'B', 'C'), number=10
    )
    print(
        f"Time for {size_1} disks: {time_1:.6f}\n"
        f"Time for {size_2} disks: {time_2:.6f}"
    )


def main(): 
    n = eval(input("Enter number of disks: ")) 
 
    # Find the solution recursively 
    moveDisks(n, 'A', 'B', 'C') 
    print(f"The number of moves is {moves}")
 

#test_move_disks()
main()