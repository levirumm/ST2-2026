import timeit


def recursive_sum_of_natural_numbers(n):
    """
    Recursive function to fund sum of natural numbers up to n.
    """
    if n == 1:
        return 1 # Base case
    else:
        return n + recursive_sum_of_natural_numbers(n - 1)


def iterative_sum_of_natural_numbers(n):
    """
    Iterative function to fund sum of natural numbers up to n.
    """
    sum = 0
    while n > 0:
        sum += n
        n -= 1
    return sum


def recursive_fibonacci(n):
    """
    Recursive function to find nth term in fibonacci sequence.
    """
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return recursive_fibonacci(n - 1) + recursive_fibonacci(n - 2)


def iterative_fibonacci(n):
    """
    Iterative function to find nth term in fibonacci 
    sequence.
    """
    terms = 0
    a = 0 # Base case
    b = 1 # Base case

    while terms < n:
        a, b = a + b, a
        terms += 1

    return a
        

def recursive_factorial(n):
    """
    Recursive function to calculate the factorial of a 
    non-negative integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * recursive_factorial(n - 1)


def iterative_factorial(n):
    """
    Iterative function to calculate the factorial of a 
    non-negative integer.
    """
    product = 1

    while n > 0:
        product *= n
        n -= 1
    
    return product


def compare_sum_of_natural_numbers():
    target_1 = 10
    target_2 = 500
    
    recursion_time_1 = timeit.timeit(
        lambda: recursive_sum_of_natural_numbers(target_1), number=10000
    )
    recursion_time_2 = timeit.timeit(
        lambda: recursive_sum_of_natural_numbers(target_2), number=10000
    )
    iterative_time_1 = timeit.timeit(
        lambda: iterative_sum_of_natural_numbers(target_1), number=10000
    )
    iterative_time_2 = timeit.timeit(
        lambda: iterative_sum_of_natural_numbers(target_2), number=10000
    )

    print(
        f"Recursive sum of numbers up to 10: {recursion_time_1}\n"
        f"Recursive sum of numbers up to 500: {recursion_time_2}\n"
        f"Iterative sum of numbers up to 10: {iterative_time_1}\n"
        f"Iterative sum of numbers up to 500: {iterative_time_2}\n"
    )


def compare_fibonacci():
    target_1 = 5
    target_2 = 20
    
    recursion_time_1 = timeit.timeit(
        lambda: recursive_fibonacci(target_1), number=10000
    )
    recursion_time_2 = timeit.timeit(
        lambda: recursive_fibonacci(target_2), number=10000
    )
    iterative_time_1 = timeit.timeit(
        lambda: iterative_fibonacci(target_1), number=10000
    )
    iterative_time_2 = timeit.timeit(
        lambda: iterative_fibonacci(target_2), number=10000
    )

    print(
        f"Recursive 5th fibonacci term: {recursion_time_1}\n"
        f"Recursive 20th fibonacci term: {recursion_time_2}\n"
        f"Iterative 5th fibonacci term: {iterative_time_1}\n"
        f"Iterative 20th fibonacci term: {iterative_time_2}\n"
    )


def compare_factorial():
    target_1 = 10
    target_2 = 500
    
    recursion_time_1 = timeit.timeit(
        lambda: recursive_factorial(target_1), number=10000
    )
    recursion_time_2 = timeit.timeit(
        lambda: recursive_factorial(target_2), number=100000
    )
    iterative_time_1 = timeit.timeit(
        lambda: iterative_factorial(target_1), number=10000
    )
    iterative_time_2 = timeit.timeit(
        lambda: iterative_factorial(target_2), number=10000
    )

    print(
        f"Recursive factorial of 10: {recursion_time_1}\n"
        f"Recursive factorial of 500: {recursion_time_2}\n"
        f"Iterative factorial of 10: {iterative_time_1}\n"
        f"Iterative factorial of 500: {iterative_time_2}\n"
    )

compare_sum_of_natural_numbers()
#compare_fibonacci()
#compare_factorial()